
public class Main
{

	/*
    *Main method. Uses SplineInterpolation constructor to create window.
    */
	public static void main(String args[])
	{
		BuildApplication app = new BuildApplication("Game");
		app.run();
	}

}