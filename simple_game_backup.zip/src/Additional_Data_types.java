
public class Additional_Data_types {
	private enum Player_Actions {Move_Left, Move_Right, Fire_Left, Fire_Right};
}
